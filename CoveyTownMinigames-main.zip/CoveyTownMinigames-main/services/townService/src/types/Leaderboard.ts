// Leaderboard type 
export type TicTacToeLeaderBoard = { [username: string]: number; };